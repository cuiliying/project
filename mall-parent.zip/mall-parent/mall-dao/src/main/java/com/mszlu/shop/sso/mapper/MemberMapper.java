package com.mszlu.shop.sso.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mszlu.shop.model.buyer.pojo.Member;

public interface MemberMapper extends BaseMapper<Member> {
}
