package com.mszlu.shop.buyer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mszlu.shop.buyer.pojo.Test;

public interface TestMapper extends BaseMapper<Test> {
}
