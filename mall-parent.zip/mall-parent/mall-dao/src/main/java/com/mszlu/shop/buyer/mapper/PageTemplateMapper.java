package com.mszlu.shop.buyer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mszlu.shop.model.buyer.pojo.PageTemplate;

public interface PageTemplateMapper extends BaseMapper<PageTemplate> {
}
