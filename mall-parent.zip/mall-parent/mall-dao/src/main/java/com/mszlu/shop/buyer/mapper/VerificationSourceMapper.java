package com.mszlu.shop.buyer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mszlu.shop.model.buyer.pojo.VerificationSource;

public interface VerificationSourceMapper extends BaseMapper<VerificationSource> {
}
