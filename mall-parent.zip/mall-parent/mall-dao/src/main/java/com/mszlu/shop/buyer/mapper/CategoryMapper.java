package com.mszlu.shop.buyer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mszlu.shop.model.buyer.pojo.Category;

public interface CategoryMapper extends BaseMapper<Category> {
}
