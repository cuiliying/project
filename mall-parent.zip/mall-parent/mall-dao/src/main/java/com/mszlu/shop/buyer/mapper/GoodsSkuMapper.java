package com.mszlu.shop.buyer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mszlu.shop.model.buyer.pojo.goods.GoodsSku;

public interface GoodsSkuMapper extends BaseMapper<GoodsSku> {
}
