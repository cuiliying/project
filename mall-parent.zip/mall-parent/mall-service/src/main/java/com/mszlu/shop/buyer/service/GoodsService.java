package com.mszlu.shop.buyer.service;

import com.mszlu.shop.model.buyer.params.EsGoodsSearchParam;
import com.mszlu.shop.model.buyer.params.PageParams;
import com.mszlu.shop.model.buyer.vo.goods.GoodsPageVo;

public interface GoodsService {
    /**
     * 根据搜索条件 进行搜索
     * @param goodsSearchParams
     * @param pageParams
     * @return
     */
    public GoodsPageVo searchGoods(EsGoodsSearchParam goodsSearchParams, PageParams pageParams);
}
