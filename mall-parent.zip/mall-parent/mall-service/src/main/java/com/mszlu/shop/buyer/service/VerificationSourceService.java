package com.mszlu.shop.buyer.service;

import com.mszlu.shop.model.buyer.vo.commons.slider.VerificationVO;

public interface VerificationSourceService {
    /**
     * 查询数据库 获取资源列表 得到资源列表和滑块列表
     * @return
     */
    VerificationVO findVerificationSource();
}
