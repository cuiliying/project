package com.mszlu.shop.buyer.service;


import com.mszlu.shop.common.vo.Result;
import com.mszlu.shop.model.buyer.vo.goods.GoodsDetailVo;

import java.util.Map;

public interface GoodsSkuService {

    void importES();

    Result<GoodsDetailVo> getGoodsSkuDetail(String goodsId, String skuId);
}
