package com.mszlu.shop.dubbo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DubboApp {

    public static void main(String[] args) {
        SpringApplication.run(DubboApp.class,args);
    }
}
