package com.mszlu.shop.common.utils.token;

public class SecurityKey {

    public static final String USER_CONTEXT = "userContext";

    public static final String ACCESS_TOKEN = "accessToken";
}
