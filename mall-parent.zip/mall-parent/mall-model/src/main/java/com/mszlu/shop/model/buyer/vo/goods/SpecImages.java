package com.mszlu.shop.model.buyer.vo.goods;

import lombok.Data;

import java.io.Serializable;

@Data
public  class SpecImages implements Serializable {


        private String url;

        private String name;

        private String status;

}