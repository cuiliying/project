package com.mszlu.shop.buyer.pojo;

import lombok.Data;

@Data
public class Test {

    private Integer id;

    private String username;
}
