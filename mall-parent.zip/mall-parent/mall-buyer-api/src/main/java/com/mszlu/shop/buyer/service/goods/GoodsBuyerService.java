package com.mszlu.shop.buyer.service.goods;

import com.mszlu.shop.buyer.service.GoodsSkuService;
import com.mszlu.shop.common.vo.Result;
import com.mszlu.shop.model.buyer.vo.goods.GoodsDetailVo;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class GoodsBuyerService {

    @DubboReference(version = "1.0.0")
    private GoodsSkuService goodsSkuService;


    public Result<GoodsDetailVo> getGoodsSkuDetail(String goodsId, String skuId) {
        /**
         * 交给dubbo服务提供者 来提供
         */
        return goodsSkuService.getGoodsSkuDetail(goodsId,skuId);
    }
}
