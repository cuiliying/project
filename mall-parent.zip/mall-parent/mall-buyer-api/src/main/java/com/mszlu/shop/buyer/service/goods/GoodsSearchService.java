package com.mszlu.shop.buyer.service.goods;

import com.mszlu.shop.buyer.service.GoodsService;
import com.mszlu.shop.model.buyer.params.EsGoodsSearchParam;
import com.mszlu.shop.model.buyer.params.PageParams;
import com.mszlu.shop.model.buyer.vo.goods.GoodsPageVo;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class GoodsSearchService {

    private static  final String HOT_WORDS_REDIS_KEY = "goods_hot_words";

    @Autowired
    private StringRedisTemplate redisTemplate;

    @DubboReference(version = "1.0.0")
    private GoodsService goodsService;

    public List<String> getHotWords(Integer start, Integer end) {
        /**
         * 1. redis的zset 数据结构
         * 2. 要按照 score 从大到小排
         * 3. redis数据来源，先用测试数据，后期做搜索的时候，redis数据 通过搜索接口放入
         */
        //从大到小排
        //start 1 end 5
        start = (start - 1) * end;
        end = start + end;
        Set<ZSetOperations.TypedTuple<String>> typedTuples = redisTemplate.opsForZSet().reverseRangeWithScores(HOT_WORDS_REDIS_KEY, start, end);
        List<String> hotWords = new ArrayList<>();
        if (typedTuples == null){
            return hotWords;
        }
        for (ZSetOperations.TypedTuple<String> typedTuple : typedTuples) {
            hotWords.add(typedTuple.getValue());
        }
        return hotWords;
    }

    public GoodsPageVo searchGoods(EsGoodsSearchParam goodsSearchParams, PageParams pageParams) {
        return goodsService.searchGoods(goodsSearchParams,pageParams);
    }
}
