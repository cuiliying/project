package com.mszlu.shop.buyer.service.impl.article;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mszlu.shop.buyer.mapper.ArticleCategoryMapper;
import com.mszlu.shop.buyer.mapper.ArticleMapper;
import com.mszlu.shop.buyer.service.ArticleService;
import com.mszlu.shop.model.buyer.params.ArticleSearchParams;
import com.mszlu.shop.model.buyer.pojo.Article;
import com.mszlu.shop.model.buyer.pojo.ArticleCategory;
import com.mszlu.shop.model.buyer.vo.article.ArticleCategoryVO;
import com.mszlu.shop.model.buyer.vo.article.ArticleVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.beans.BeanUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@DubboService(version = "1.0.0",interfaceClass = ArticleService.class)
public class ArticleServiceImpl implements ArticleService {

    @Resource
    private ArticleMapper articleMapper;

    @Override
    public Page<ArticleVO> articlePage(ArticleSearchParams articleSearchParams) {
        /**
         * 1. 查询条件 有多个
         * 2. 查询条件 进行判断 ，如果不为null 才进行条件查询
         * 3. 分页参数，分页查询
         * 4. 从 Article 转换为 ArticleVo ，表的字段 并不是都有用，用多少查多少
         * 5. copy copyList 做Article 转换为 ArticleVo工作
         */
        if (!articleSearchParams.checkParams()){
            //参数校验
            return new Page<>();
        }
        Page<Article> articlePage = new Page<>(articleSearchParams.getPageNumber(),articleSearchParams.getPageSize());
        LambdaQueryWrapper<Article> queryWrapper = new LambdaQueryWrapper<>();
        if (StringUtils.isNotBlank(articleSearchParams.getCategoryId())) {
            queryWrapper.eq(Article::getCategoryId,articleSearchParams.getCategoryId());
        }
        if (StringUtils.isNotBlank(articleSearchParams.getTitle())) {
            // like 'aa%'
            queryWrapper.likeRight(Article::getTitle,articleSearchParams.getTitle());
        }
        if (StringUtils.isNotBlank(articleSearchParams.getType())) {
            queryWrapper.eq(Article::getType,articleSearchParams.getType());
        }
        queryWrapper.select(Article::getCategoryId,Article::getId,Article::getTitle,Article::getType);
        Page<Article> articlePage1 = articleMapper.selectPage(articlePage, queryWrapper);
        Page<ArticleVO> articleVOPage = new Page<>();
        BeanUtils.copyProperties(articlePage1,articleVOPage);
        List<Article> records = articlePage1.getRecords();
        List<ArticleVO> articleVOList = copyList(records);
        articleVOPage.setRecords(articleVOList);
        return articleVOPage;
    }

    @Override
    public ArticleVO findArticleVoList(Long id) {
        Article article = articleMapper.selectById(id);
        return copy(article);
    }

    public ArticleCategoryVO copyCategory(ArticleCategory article){
        if (article == null){
            return null;
        }
        ArticleCategoryVO articleVO = new ArticleCategoryVO();

        BeanUtils.copyProperties(article,articleVO);
        articleVO.setId(article.getId().toString());
        articleVO.setParentId(article.getParentId().toString());
        return articleVO;
    }

    public  List<ArticleCategoryVO> copyCategoryList(List<ArticleCategory> articleList){
        List<ArticleCategoryVO> articleVOList = new ArrayList<>();

        for (ArticleCategory article : articleList) {
            articleVOList.add(copyCategory(article));
        }
        return articleVOList;
    }

    @Resource
    private ArticleCategoryMapper articleCategoryMapper;


    @Override
    public List<ArticleCategoryVO> findAllArticleCategory() {
        /**
         * 1. 查找所有的文章分类 信息，为了速度
         * 2. 代码组树形结构 (递归)
         */
        LambdaQueryWrapper<ArticleCategory> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ArticleCategory::getDeleteFlag,false);

        List<ArticleCategory> articleCategories = articleCategoryMapper.selectList(queryWrapper);
        List<ArticleCategoryVO> articleCategoryVOList = copyCategoryList(articleCategories);

        List<ArticleCategoryVO> articleCategoryVOS = new ArrayList<>();

        for (ArticleCategoryVO articleCategoryVO : articleCategoryVOList) {
            if (articleCategoryVO.getParentId().equals("0")){
                articleCategoryVOS.add(articleCategoryVO);
                addCategoryChild(articleCategoryVO,articleCategoryVOList);
            }
        }
        return articleCategoryVOS;
    }

    private void addCategoryChild(ArticleCategoryVO articleCategoryVO, List<ArticleCategoryVO> articleCategoryVOList) {
        List<ArticleCategoryVO> categoryVOList = new ArrayList<>();
        for (ArticleCategoryVO categoryVO : articleCategoryVOList) {
            if (articleCategoryVO.getId().equals(categoryVO.getParentId())){
                categoryVOList.add(categoryVO);
                addCategoryChild(categoryVO,articleCategoryVOList);
            }
        }
        articleCategoryVO.setChildren(categoryVOList);
    }

    public ArticleVO copy(Article article){
        if (article == null){
            return null;
        }
        ArticleVO articleVO = new ArticleVO();

        BeanUtils.copyProperties(article,articleVO);
        articleVO.setId(article.getId().toString());
        return articleVO;
    }
    public  List<ArticleVO> copyList(List<Article> articleList){
        List<ArticleVO> articleVOList = new ArrayList<>();

        for (Article article : articleList) {
            articleVOList.add(copy(article));
        }
        return articleVOList;
    }
}
