package com.mszlu.shop.buyer.service.impl.common;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mszlu.shop.buyer.mapper.VerificationSourceMapper;
import com.mszlu.shop.buyer.service.VerificationSourceService;
import com.mszlu.shop.model.buyer.eums.VerificationSourceEnum;
import com.mszlu.shop.model.buyer.pojo.VerificationSource;
import com.mszlu.shop.model.buyer.vo.commons.VerificationSourceVo;
import com.mszlu.shop.model.buyer.vo.commons.slider.VerificationVO;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.beans.BeanUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@DubboService(version = "1.0.0",interfaceClass = VerificationSourceService.class)
public class VerificationSourceServiceImpl implements VerificationSourceService {
    @Resource
    private VerificationSourceMapper verificationSourceMapper;

    @Override
    public VerificationVO findVerificationSource() {
        LambdaQueryWrapper<VerificationSource> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(VerificationSource::getDeleteFlag,false);
        List<VerificationSource> verificationSources = verificationSourceMapper.selectList(queryWrapper);

        List<VerificationSourceVo> verificationResources = new ArrayList<>();
        List<VerificationSourceVo> verificationSliders = new ArrayList<>();
        for (VerificationSource verificationSource : verificationSources) {
            if (verificationSource.getType().equals(VerificationSourceEnum.SLIDER.name())){
                verificationSliders.add(copy(verificationSource));
            }
            if (verificationSource.getType().equals(VerificationSourceEnum.RESOURCE.name())){
                verificationResources.add(copy(verificationSource));
            }
        }
        VerificationVO verificationVO = new VerificationVO();
        verificationVO.setVerificationResources(verificationResources);
        verificationVO.setVerificationSlider(verificationSliders);

        return verificationVO;
    }

    public VerificationSourceVo copy(VerificationSource verificationSource){
        if (verificationSource == null){
            return null;
        }
        VerificationSourceVo verificationSourceVo = new VerificationSourceVo();
        BeanUtils.copyProperties(verificationSource,verificationSourceVo);
        return verificationSourceVo;
    }

    public List<VerificationSourceVo> copyList(List<VerificationSource> verificationSourceList){
        List<VerificationSourceVo> verificationSourceVoList = new ArrayList<>();
        for (VerificationSource verificationSource : verificationSourceList) {
            verificationSourceVoList.add(copy(verificationSource));
        }
        return verificationSourceVoList;
    }
}
